package hms;

import java.sql.*;

public class Reservation {
	 private int id;
	 private int roomId;
	 private int guestId;
	 private java.util.Date checkInDate;
	 private java.util.Date checkOutDate;
	 public Reservation(int id, int roomId, int guestId, java.util.Date checkInDate, java.util.Date checkOutDate) {
	 this.id = id;
	 this.roomId = roomId;
	 this.guestId = guestId;
	 this.checkInDate = checkInDate;
	 this.checkOutDate = checkOutDate;
	 }
	 public int getId() {
	 return id;
	 }
	 public void setId(int id) {
	 this.id = id;
	 }
	public int getRoomId() {
	 return roomId;
	 }
	 public void setRoomId(int roomId) {
	 this.roomId = roomId;
	 }
	 public int getGuestId() {
	 return guestId;
	 }
	 public void setGuestId(int guestId) {
	 this.guestId = guestId;
	 }
	 public java.util.Date getCheckInDate() {
	 return checkInDate;
	 }
	 public void setCheckInDate(Date checkInDate) {
	 this.checkInDate = checkInDate;
	 }
	public java.util.Date getCheckOutDate() {
	 return checkOutDate;
	 }
	 public void setCheckOutDate(Date checkOutDate) {
	 this.checkOutDate = checkOutDate;
	 }
	 }
